define(["jquery","underscore","backbone"],function(a,b,c){return c.Model.extend({idAttribute:"cluster_id",initialize:function(){}})});
//# sourceMappingURL=MultiCluster.f44039d5.js.map